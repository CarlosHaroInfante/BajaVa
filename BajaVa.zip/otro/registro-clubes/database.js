const clubs = [
    {
        nombre_club: 'Club A',
        colores_club: 'Rojo y Blanco',
        mail_club: 'cluba@example.com',
        contraseña_club: 'pass123'
    },
    {
        nombre_club: 'Club B',
        colores_club: 'Azul y Amarillo',
        mail_club: 'clubb@example.com',
        contraseña_club: 'pass456'
    }
];

module.exports = clubs;
