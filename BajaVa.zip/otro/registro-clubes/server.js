const express = require('express');
const cors = require('cors'); // Importa el paquete cors
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;
const clubsPath = './clubs.json';

// Middleware para manejar CORS
app.use(cors()); // Habilita CORS para todas las rutas

// Middleware para manejar solicitudes JSON
app.use(bodyParser.json());
app.use(express.static('public')); // Para servir archivos estáticos

// Función para leer los clubes del archivo JSON
const readClubs = () => {
    try {
        const data = fs.readFileSync(clubsPath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error("Error leyendo clubs.json:", error);
        return [];
    }
};

// Función para guardar los clubes en el archivo JSON
const saveClubs = (clubs) => {
    try {
        fs.writeFileSync(clubsPath, JSON.stringify(clubs, null, 2), 'utf-8');
    } catch (error) {
        console.error("Error escribiendo en clubs.json:", error);
    }
};

// Ruta para registrar un club
app.post('/api/register', (req, res) => {
    const { nombre_club, colores_club, mail_club, contraseña_club } = req.body;

    // Validación de datos
    if (!nombre_club || !colores_club || !mail_club || !contraseña_club) {
        return res.status(400).json({ error: 'Todos los campos son requeridos' });
    }

    // Leer clubes actuales
    const clubs = readClubs();

    // Comprobar si el club ya está registrado
    const existingClub = clubs.find(club => club.mail_club === mail_club);
    if (existingClub) {
        return res.status(409).json({ error: 'El club ya está registrado con este correo' });
    }

    // Agregar el nuevo club y guardar en el archivo
    const newClub = { nombre_club, colores_club, mail_club, contraseña_club };
    clubs.push(newClub);
    saveClubs(clubs);

    return res.status(201).json({ message: 'Club registrado exitosamente' });
});

// Ruta para eliminar un club
app.post('/deleteClub', (req, res) => {
    const { name } = req.body;

    const clubs = readClubs();
    const initialLength = clubs.length;
    const updatedClubs = clubs.filter(club => club.nombre_club !== name);

    if (updatedClubs.length === initialLength) {
        return res.status(404).json({ success: false, message: 'No se encontró un club con ese nombre' });
    }

    saveClubs(updatedClubs);
    return res.json({ success: true, message: `El club "${name}" ha sido eliminado.` });
});

// Ruta para servir el archivo HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html')); // Asegúrate de que la ruta sea correcta
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
